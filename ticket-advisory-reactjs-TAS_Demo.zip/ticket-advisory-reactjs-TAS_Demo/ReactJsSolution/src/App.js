import React, { Component } from 'react';
import Dashboard from "./components/Dashboard"
import './App.css';

import { Provider } from 'react-redux';
// import ReduxPromise from 'redux-promise';
// import { createStore, applyMiddleware } from 'redux';
// import reducers from './reducers';
import store from './store';
import  './assets/scss/fonts.scss' 

//const createStoreWithMiddleware = applyMiddleware(ReduxPromise)(createStore);

//#region Theme Changes
import SopraSteriaTheme from './assets/theme/material-ui.config'
import { MuiThemeProvider} from '@material-ui/core/styles';
// const theme = createMuiTheme({
//   palette: {
//     primary: { main: "#cf022b" }, // Purple and green play nicely together.
//     secondary: { main: '#aaa' }, // This is just green.A700 as hex.
//   },
// });
//#endregion


class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <MuiThemeProvider theme={SopraSteriaTheme}>
          <Dashboard></Dashboard>
        </MuiThemeProvider>
      </Provider>
    );
  }
}

export default App;

