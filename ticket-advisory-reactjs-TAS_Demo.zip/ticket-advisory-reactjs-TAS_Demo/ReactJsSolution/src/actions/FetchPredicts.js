export default function FetchPredicts(products) {
  
   return {
        type: 'FETCH_PREDICTS',
        payload: products
   }
}