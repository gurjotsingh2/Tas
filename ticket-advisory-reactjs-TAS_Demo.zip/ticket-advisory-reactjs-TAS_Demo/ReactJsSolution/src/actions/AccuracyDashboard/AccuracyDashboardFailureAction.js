
import {ACCURACY_DASHBOARD_FAILURE} from "../../constants/constants";

export default function AccuracyDashboardFailure(data) {
    return {
        type:ACCURACY_DASHBOARD_FAILURE,
        payload:data
    }
}
