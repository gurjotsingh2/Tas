
import {ACCURACY_DASHBOARD_SUCCESS} from "../../constants/constants";

export default function AccuracyDashboardSuccess(data) {
    
    return {
        type:ACCURACY_DASHBOARD_SUCCESS,
        payload:data
    }
}
