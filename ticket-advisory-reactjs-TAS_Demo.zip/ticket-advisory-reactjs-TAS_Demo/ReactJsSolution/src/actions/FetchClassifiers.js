import {FETCH_CLASSIFIER} from "../constants/constants";

export default function FetchClassifiers(Approach) {
   return {
        type: FETCH_CLASSIFIER,
        payload: Approach
   }
}


