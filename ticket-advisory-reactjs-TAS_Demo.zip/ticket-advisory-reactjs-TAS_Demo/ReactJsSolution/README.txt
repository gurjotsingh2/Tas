ReactJs solution for Ticket Advisory System.    
   