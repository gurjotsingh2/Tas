import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { API_URL } from '../../constants/constants';

//#region Action
import SelectedTrainType from '../../actions/SelectedTrainType';
//#endregion
import FileUploader from "../../components/FileUploader"
// Service
import PatternDetectionModelService from '../../services/PatternDetection/PatternDetectionModelService';
//#region Material Import
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Grid from '@material-ui/core/Grid';
import { withStyles, Table } from '@material-ui/core';
import PropTypes from 'prop-types';
import Button from "@material-ui/core/Button";
import DeleteIcon from '@material-ui/icons/Delete';
import AddIcon from '@material-ui/icons/Add';
import PatternDetectionSave from '../../services/PatternDetection/PatternDetectionSave';
import { Typography } from '@material-ui/core';
import PredictFileUploadAction from "../../actions/Predict/predictFileUploadAction";
import Snackbar from '@material-ui/core/Snackbar';
import Input from '@material-ui/core/Input';
import Fab from '@material-ui/core/Fab';
import Icon from '@material-ui/core/Icon';
import Tooltip from '@material-ui/core/Tooltip';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Loader from 'react-loader-spinner';
import FullLoader from './src/containers/loader/FullLoader';
//#endregion 


//#region style
const styles = theme => ({
    paper: {
        height: 140,
        width: 100,
    }, container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    fab: {

    },
    extendedIcon: {

    },
    input: {
        margin: theme.spacing.unit,
    },
    control: {
        padding: theme.spacing.unit * 2,
    },
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    submitButton: {
        backgroundColor: 'Green',
    },
    title: {
        color: '#CF022B',
        fontSize: '1.3125rem',
        fontWeight: '500',
        lineHeight: '1.16667em',
        fontFamily: 'Soho Gothic Pro'

    },
    tabRoot: {
        border: '2px solid #e8e8e8',
    },
    snackbarColor: {
        background: '#CF022B'
    },
    epMarginBottom: {
        marginBottom: '10px',
    },
    epMarginBottomFirst: {
        marginTop: '-10px',
        marginBottom: '10px',
    },
    checkBoxMargin: {
        marginLeft: '30%'
    },
    tdWidth: {
        width: '125px'
    },
    textboxPattern: {
        marginLeft: '3%',
        marginBottom: '1%'
    },
    textbox: {
        marginBottom: '1%',
        marginLeft: '3%',
        minWidth: '80%'
    },
    deleteIcon: {
        height: 24,
        width: '36px',
        marginLeft: '3%',
        cursor: 'pointer',
        marginBottom: '-10px'
    },
    fabClassAdd: {
        height: '1px',
        width: '36px',
        marginLeft: '.5%',
        cursor: 'pointer'
    },
    floatRight: {
        margin: '0px',
        top: 'auto',
        right: '20px',
        bottom: '40px',
        left: 'auto',
        position: 'fixed'
    }
});

//#endregion

class DropDownPatternDetection extends Component {

    constructor(props) {
        super(props);
        // this.state = {
        //     classifier:'',comments: ' ' ,language: [],
        //     outcome:'',regex: [],vector: '',checked: false,
        //     trainType: this.props.selectedTrainTypeValue,TrainType: this.props.trainTypes[0].outcome
        //     };
        this.state = {
            classifier: '', comments: ' ', language: [],
            outcome: '', regex: [], vector: '', checked: false,
            trainType: this.props.trainTypes[0].outcome, TrainType: this.props.trainTypes[0].outcome, initialLoad: true, isCheckedEnglish: false, isCheckedFrench: false
            , isCheckedGerman: false, isCheckedSpanish: false,  'ShowTable': false
            , open: false, vertical: 'top', horizontal: 'right', errorMessage: ''
        };

        this.handleClose = this.handleClose.bind(this);

        //Call API for Fetch Previous saved data i.e retrieve_user_config 
        this.props.PatternDetectionModelService(this.state.TrainType);



        this.handleChange = this.handleChange.bind(this);
        // this.setState({ trainType: this.props.trainTypes });
        //Setting initial State


        this.handleChange = this.handleChange.bind(this);

        this.addRow = this.addRow.bind(this);
        this.handlesaveTodoItem = this.handlesaveTodoItem.bind(this);


        this.ResetResponseMessage();

    }

    handleChange = name => event => {
        this.setState({ initialLoad: true });
        this.setState({ [name]: event.target.value });
        this.ResetResponseMessage();

        if (name === "TrainType") {
            this.props.SelectedTrainType(event.target.value);
        }
        //Call API for Fetch Previous saved data i.e retrieve_user_config  
        this.props.PatternDetectionModelService(event.target.value);

    };

    ResetResponseMessage() {
        this.props.PatternDetectionPrevSaveValue.data = '';
    }

    handleRowDel(index) {
        this.ResetResponseMessage();
        let regexArray = this.state.regex;
        regexArray.splice(index, 1);
        this.setState({ regex: regexArray });
    }

    handleChangeCommentColumn(event) {

        this.ResetResponseMessage();
        this.setState({ comments: event.target.value });
    }

    handleChanged(prevdata, i, event) {
        this.ResetResponseMessage();
        let values = this.state.regex;
        let value = event.target.name;
        if (values.length === 0) {
            if (i === 0) {
                values[0] = event.target.value;
                values[1] = '';
            } else if (i === 1) {
                values[0] = '';
                values[1] = event.target.value;
            }
        } else {
            if (value === 'name') {
                if (event.target.value === "") {
                    values[i].name = '';
                } else {
                    values[i].name = event.target.value;
                }

            } else if (value === 'endName') {
                if (event.target.value === "") {
                    values[i].endName = '';
                } else {
                    values[i].endName = event.target.value;
                }
            }
        }

        this.setState({ regex: values });
    }

    addRow() {
        this.ResetResponseMessage();
        let regexArrayy = { endName: '', name: '' };
        let regex = this.state.regex;
        if (regex.length === 0) {
            regex.push(regexArrayy);
            this.setState({ regex: regex });
        } else {
            for (let i = 0; i < this.state.regex.length; i++) {
                if (this.state.regex[i].name === undefined || this.state.regex[i].name === "" || this.state.regex[i].endName === undefined || this.state.regex[i].endName === "") {
                   // alert("Please enter Pattern values");
                   this.setState({ open: true, errorMessage: 'Please enter Pattern values.' });
                    return;
                }



            }
            regex.push(regexArrayy);
            this.setState({ regex: regex });
            return;
        }
    }

    handleClose() {
        this.setState({ open: false });
    };


    handlesaveTodoItem() {
        
        this.setState({ saveClicked: true });
        if (this.props.uploadStatus === true) {

        }
        else {
            this.setState({ open: true, errorMessage: 'Please Upload a file.' });
            return;
        }

        this.state.language.push();
        let data = {
            classifier: this.state.classifier,
            comments: this.state.comments,
            language: this.state.language,
            outcome: this.state.outcome,
            regex: this.state.regex,
            vector: this.state.vector
        }
        this.setState({ 'ShowTable': true });
        this.props.PatternDetectionSave(data);
    };

    handleChangeCheckBox(e) {
        this.ResetResponseMessage();

        let lang = this.state.language;
        if (e.target.name === "english") {
            if (e.target.checked) {
                this.setState({ isCheckedEnglish: true });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i].name === "english") {
                        return;
                    }
                } lang.push("english");
                this.setState({ language: lang });
            } else {
                this.setState({ isCheckedEnglish: false });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i] === "english") {
                        lang.pop("english");
                        this.setState({ language: lang });
                        return;
                    }
                }
            }
        } else if (e.target.name === "french") {
            if (e.target.checked) {
                this.setState({ isCheckedFrench: true });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i].name === "french") {
                        return;
                    }
                } lang.push("french");
                this.setState({ language: lang });
            } else {
                this.setState({ isCheckedFrench: false });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i] === "french") {
                        lang.pop("french");
                        this.setState({ language: lang });
                        return;
                    }
                }
            }
        }
        else if (e.target.name === "german") {
            if (e.target.checked) {
                this.setState({ isCheckedGerman: true });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i].name === "german") {
                        return;
                    }
                } lang.push("german");
                this.setState({ language: lang });
            } else {
                this.setState({ isCheckedGerman: false });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i] === "german") {
                        lang.pop("german");
                        this.setState({ language: lang });
                        return;
                    }
                }
            }
        } else if (e.target.name === "spanish") {
            if (e.target.checked) {
                this.setState({ isCheckedSpanish: true });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i].name === "spanish") {
                        return;
                    }
                } lang.push("spanish");
                this.setState({ language: lang });
            } else {
                this.setState({ isCheckedSpanish: false });
                for (let i = 0; i < this.state.language.length; i++) {
                    if (this.state.language[i] === "spanish") {
                        lang.pop("spanish");
                        this.setState({ language: lang });
                        return;
                    }
                }
            }
        }
    }

    componentDidUpdate() {

        const { data } = this.props.PatternDetectionPrevSaveValue;

        if (data) {

            if (this.state.initialLoad) {
                this.setState({ initialLoad: false });


                this.setState({
                    classifier: data[0].classifier, comments: data[0].comments, language: data[0].language,
                    outcome: data[0].outcome, regex: data[0].regex, vector: data[0].vector
                })

            }


            // When trainType dropdown changes needs to reset 
            if (this.state.trainType !== this.props.selectedTrainTypeValue &&
                this.state.regex !== data[0].regex &&
                this.state.classifier !== data[0].classifier &&
                this.state.comments !== data[0].comments
            ) {
                this.setState({ trainType: this.props.selectedTrainTypeValue });
                this.setState({ initialLoad: true });
                // this.ResetResponseMessage();



                for (let i = 0; i < data[0].language.length; i++) {
                    if (data[0].language[i] === "english") {
                        this.setState({ isCheckedEnglish: true });
                    } else if (data[0].language[i] === "spanish") {
                        this.setState({ isCheckedSpanish: true });
                    } else if (data[0].language[i] === "german") {
                        this.setState({ isCheckedGerman: true });
                    } else if (data[0].language[i] === "french") {
                        this.setState({ isCheckedFrench: true });
                    }

                }
            }

        }

        if (this.props.PatternDetectionSaveValue !== undefined || this.props.PatternDetectionSaveValue !== null) {
            if (this.props.PatternDetectionSaveValue.data !== '') {
                if (this.state.saveClicked === true) {
                    if (this.props.PatternDetectionSaveValue.data.Message) {
                        this.setState({ open: true, errorMessage: this.props.PatternDetectionSaveValue.data.Message });
                    }
                    else if (this.props.PatternDetectionSaveValue.data.Error) {
                        let message = 'Error: ' + this.props.PatternDetectionSaveValue.data.Error + '. ' +
                            this.props.PatternDetectionSaveValue.data.Exception
                        this.setState({ open: true, errorMessage: message });
                    }
                    this.setState({ saveClicked: false });
                }
            }
        }

    }

    render() {
        
        const { classes } = this.props;
        const togglecheck1 = this.state.checked ? 'hidden-check1' : '';
        const { data } = this.props.PatternDetectionSaveValue;


        const divstyle = {
            backgroundColor: 'white',
            width: '100px',
            color: 'black',
            marginTop: '10px'
        }
        let url = API_URL + 'train_upload';

        return (

            <form >

                {/* // <Grid>
                //     <Grid container className={classes.root} spacing={24}>
                //         <Grid item xs={12} sm={12}> */}

                {/* TrainTypes ddl */}
                <ExpansionPanel></ExpansionPanel>
                <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>Use Case</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>

                        <FormControl className={this.props.formControl} style={{ marginLeft: '3%' }} >
                            <Select placeholder="Use Case" autoWidth={true} style={{ width: 'auto', minWidth: '150px' ,fontFamily: 'Soho Gothic Pro'}}
                                value={this.state.TrainType}
                                onChange={this.handleChange('TrainType')}>
                                {
                                    this.props.trainTypes.map((item) => {
                                        return <MenuItem key={item.id} value={item.outcome}>{item.name}</MenuItem>
                                    })
                                }
                            </Select>
                        </FormControl>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                {/* //         </Grid>

                //     </Grid>
                // </Grid> */}

                {/* <Grid container className={classes.root} spacing={24}>
                    <Grid item xs={12} sm={12}> */}
                <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>File Upload</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>
                        <div style={{ width: '100%' }}>
                            <Tooltip title="Upload a file">
                                <FileUploader style={{ marginLeft: '2%' }} key="predictFileUploader"
                                    url={url}>
                                </FileUploader>
                            </Tooltip>
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>Language</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>

                        <table className="table table-bordered" >
                            <thead>
                                <div >
                                    <tr >
                                        <td className={classes.tdWidth}>
                                            <input className={classes.checkBoxMargin} onChange={this.handleChangeCheckBox.bind(this)} id="english" name="english" type="checkbox" checked={this.state.isCheckedEnglish} />
                                            <label htmlFor={this.id}>English</label>

                                        </td>
                                        <td className={classes.tdWidth}>
                                            <input className={classes.checkBoxMargin} onChange={this.handleChangeCheckBox.bind(this)} id="french" name="french" type="checkbox" checked={this.state.isCheckedFrench} />
                                            <label htmlFor={this.id}>French</label></td>
                                        <td className={classes.tdWidth}>
                                            <input className={classes.checkBoxMargin} onChange={this.handleChangeCheckBox.bind(this)} id="german" name="german" type="checkbox" checked={this.state.isCheckedGerman} />
                                            <label htmlFor={this.id}>German</label></td>
                                        <td className={classes.tdWidth}>
                                            <input className={classes.checkBoxMargin} onChange={this.handleChangeCheckBox.bind(this)} id="spanish" name="spanish" type="checkbox" checked={this.state.isCheckedSpanish} />
                                            <label htmlFor={this.id}>Spanish</label></td>

                                    </tr></div>
                            </thead></table>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>Pattern</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>

                        {
                            data === undefined || data === null ? null
                                :
                                <Table>
                                <div style={{ width: '100%'}}>
                                    {
                                        this.state.regex.map((x, i) => {
                                            return <div key={i}>
                                                {
                                                    
                                                    <tr>
                                                    <td style={{ width: '5%'}}>
                                                    <Tooltip title='Delete'>                                                                        
                                                        <DeleteIcon color="primary" className={classes.deleteIcon} onClick={this.handleRowDel.bind(this, i)}/>
                                                    </Tooltip>                                                        
                                                    </td>

                                                    <td style={{ width: '45%'}}>
                                                        <Input
                                                            id="name" name="name" style={{ width: '95%'}}
                                                            placeholder="Pattern matching text/value begins with"
                                                            variant="outlined" onChange={this.handleChanged.bind(this, x, i)}
                                                            value={this.state.regex[i].name ? this.state.regex[i].name : ''}
                                                        />
                                                        </td>

                                                    <td style={{ width: '45%'}}>
                                                        <Input
                                                            id="endName" name="endName"  style={{ width: '90%', marginLeft: '15%'}}
                                                            placeholder="Pattern matching text/value ends with"
                                                            variant="outlined" onChange={this.handleChanged.bind(this, x, i)}
                                                            value={this.state.regex[i].endName ? this.state.regex[i].endName : ''}
                                                        />
                                                        </td>                                                       
                                                    </tr>
                                                    
                                                }
                                            </div>                                          
                                        })
                                    }
                                </div>
                                <tr>
                                <Tooltip title='Add'>
                             <br />
                             <Fab color="primary" className={classes.fabClassAdd}  
                                             onClick={this.addRow}>
                                             <AddIcon />
                                            </Fab>
                        </Tooltip>
                                </tr>
                                </Table>
                        }
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>Add a Comment</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                            <Input
                                id="add-comment"
                                label="" variant="outlined" onChange={this.handleChangeCommentColumn.bind(this)}
                                className={classes.textbox} value={this.state.comments ? this.state.comments : null}
                                margin="normal" placeholder='Add Comment here'
                            />

                    </ExpansionPanelDetails>
                </ExpansionPanel>

                
                {
                    this.state.ShowTable && (data === undefined || data === null || data === '') ?
                        <div>
                            Please wait...
                        <br />
                            {/* <Loader type="Oval" color="#ec1d0d" height="75" width="75" /> */}
                            <FullLoader />
                        </div>
                        : null
                }

                <tr><td>
                    <Tooltip title="Save">
                        <Fab aria-label="Save"
                            variant="outlined"
                            color="primary"
                            disableRipple
                            className={classes.floatRight}
                            onClick={this.handlesaveTodoItem}>
                            <Icon>save_icon</Icon>
                        </Fab></Tooltip>
                </td></tr>

                <Snackbar autoHideDuration={5000} open={this.state.open} onClose={this.handleClose}
                    ContentProps={{
                        classes: {
                            root: classes.snackbarColor
                        }
                    }}
                    anchorOrigin={{ 'vertical': this.state.vertical, 'horizontal': this.state.horizontal }}
                    message={<span id="message-id" > {this.state.errorMessage}</span>} />


                {/* 
                    
                            <table className="table table-bordered" >
                                <thead>
                                    <div>
                                        {
                                            data === undefined || data === null ? null
                                                :
                                                <div>
                                                      <ExpansionPanel className={classes.epMarginBottom}>>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                        <Typography variant="title" className={classes.title}>Pattern</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                                                    {
                                                        
                                                        this.state.regex.map((x, i) => {
                                                            return <div key={i}>
                                                                {

                                                                    <div className={classes.container}>

                                                                        <tr >
                                                                            <td >
                                                                                <Input
                                                                                    id="name" name="name" className={classes.textbox}
                                                                                    placeholder="start point matching" variant="outlined" onChange={this.handleChanged.bind(this, x, i)}
                                                                                    value={this.state.regex[i].name ? this.state.regex[i].name : ''}
                                                                                />
                                                                                &nbsp; &nbsp; &nbsp;
                                                                                <Input
                                                                                    id="endName" name="endName" className={classes.textbox}
                                                                                    placeholder="end point matching" variant="outlined" onChange={this.handleChanged.bind(this, x, i)}
                                                                                    value={this.state.regex[i].endName ? this.state.regex[i].endName : ''}
                                                                                />
                                                                                 <Tooltip title="Delete">
                                                                                <Button color="primary" disableRipple onClick={this.handleRowDel.bind(this, i)}
                                                                                    style={divstyle} >
                                                                                    <DeleteIcon></DeleteIcon>
                                                                                </Button></Tooltip>
                                                                            </td>



                                                                        </tr>
                                                                        <br />
                                                                    </div>
                                                                }
                                                            </div>
                                                        }

                                                        )

                                                    }
                                                    </ExpansionPanelDetails>
                                                    </ExpansionPanel>
                                                   
                                                    <br />{
                                                        <div>
                                                            <tr><td>
                                                            <Tooltip title="Add">
                                                                <Fab color="primary" aria-label="Add" variant="outlined" disableRipple onClick={this.addRow}>
                                                                    <AddIcon />
                                                                </Fab></Tooltip>
                                                            </td></tr><tr>
                                                                <th className={classes.title} align='left'>Add a Comment</th>
                                                            </tr>
                                                            <tr className="eachRow">
                                                                <td >
                                                                    <div className={classes.container}>

                                                                        <Input
                                                                            id="add-comment"
                                                                            label="" variant="outlined" onChange={this.handleChangeCommentColumn.bind(this)}
                                                                            className={classes.input} value={this.state.comments ? this.state.comments : null}
                                                                            margin="normal" placeholder='Add Comment here'
                                                                        />

                                                                    </div>

                                                                </td></tr></div>
                                                            }

                                                    <tr><td>
                                                        <Tooltip title="Save">
                                                        <Fab aria-label="Save" 
                                                            variant="outlined"
                                                            color="primary"
                                                            disableRipple
                                                            onClick={this.handlesaveTodoItem}>
                                                            <Icon>save_icon</Icon>
                                                        </Fab></Tooltip>
                                                    </td></tr>

                                                    <Snackbar  autoHideDuration={5000} open={this.state.open} onClose={this.handleClose}
                                                        ContentProps={{
                                                            classes: {
                                                                root: classes.snackbarColor
                                                            }
                                                        }}
                                                        anchorOrigin={{ 'vertical': this.state.vertical, 'horizontal': this.state.horizontal }}
                                                        message={<span id="message-id" > {this.state.errorMessage}</span>} />
                                                    <br />
                                                    <br />
                                                    {/* {
                                                       
                                                        this.props.PatternDetectionSaveValue === undefined || this.props.PatternDetectionSaveValue === null ?
                                                            null
                                                            :
                                                            <div>
                                                                <div>
                                                                    {
                                                                        this.props.PatternDetectionSaveValue.data !== '' ?
                                                                            <div>
                                                                                {
                                                                                    this.props.PatternDetectionSaveValue.data.Message ?
                                                                                        <div className="alert alert-success ">
                                                                                            {this.props.PatternDetectionSaveValue.data.Message}
                                                                                        </div>
                                                                                        :
                                                                                        <div>
                                                                                            {
                                                                                                this.props.PatternDetectionSaveValue.data.Error ?
                                                                                                    <div className="alert alert-danger ">
                                                                                                        {this.props.PatternDetectionSaveValue.data.Error}
                                                                                                        <br />
                                                                                                        {this.props.PatternDetectionSaveValue.data.Exception}
                                                                                                    </div>
                                                                                                    : null
                                                                                            }
                                                                                        </div>
                                                                                }
                                                                            </div>
                                                                            :
                                                                            null
                                                                    }
                                                                </div>
                                                            </div>
                                                    } */}


                {/* 
                                                </div>
                                       
                                       }
                                    </div>






                                </thead>

                              

                            </table>

                       */}
                {/* } */}
                {/* </Grid>
                </Grid> */}
            </form>
        );

    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        SelectedTrainType: SelectedTrainType,
        PatternDetectionModelService: PatternDetectionModelService,
        PatternDetectionSave: PatternDetectionSave,
        fileUploadStatus: PredictFileUploadAction
    }, dispatch)
}

function mapStateToProps(state) {
    return {
        data: state.data,
        trainTypes: state.trainTypes,
        PatternDetectionModelValue: state.PatternDetectionModelValue,
        PatternDetectionPrevSaveValue: state.PatternDetectionPrevSaveValue,
        PatternDetectionSaveValue: state.PatternDetectionSaveValue,
        uploadStatus: state.predictFileUploadStatus
    }
}

DropDownPatternDetection.propTypes = {
    classes: PropTypes.object.isRequired,
};
export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(DropDownPatternDetection))
