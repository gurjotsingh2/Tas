import { Component, AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { environment } from '../../../environments/environment';
import { ManualUpload } from '../../manual-upload';
import { Http } from '@angular/http';
const URL = environment.API_URL + '/predict_upload';
import { AppConst } from '../constData';
import * as XLSX from 'xlsx';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xls';
import * as FileSaver from 'file-saver';
import { PredictedDataService } from '../../services/predicted-data.service';
@Component({
  selector: 'score-dashboard',
  templateUrl: './score-dashboard.component.html',
  styleUrls: ['./score-dashboard.component.css']
})

export class ScoreDashboardComponent implements OnInit,AfterViewInit,OnDestroy {
  public uploader: FileUploader = new FileUploader({ url: URL });
  feedbackpupload: string = '';
  feedbackpuploaderror = "";
  pv: string;
  outCome: string = 'BIT_Keywords_List';
  uperror: string = '';
  file_upload: string = 'true';
  caution2: boolean = false;
  caution: boolean = false;
  loadershow: boolean;
  errupmessage: string = '';
  dataLength = 0;
  _uploadpredict: ManualUpload[] = null;
  vector = 'tfidf';
  unseen_test_data = [];
  predictor: string = 'Notes';
  classifierHeaders = [];
  predictedScores: any = null;
  detailedResultView = false;


  constructor( private http: Http, private predictService: PredictedDataService ) {}

  ngOnInit() {
    const predictedData = this.predictService.getPredictedReport();
    const predictedDetailReport = this.predictService.getPredictedDetailReport();
    if (predictedData != null) {
      this._uploadpredict = predictedData;
      this.dataLength = this._uploadpredict.length;
      this.errupmessage = undefined;
    }
    if (predictedDetailReport != null) {
      this.predictedScores = predictedDetailReport;
      this.detailedResultView = true;
      this.createTableHeaders();
    }
  }


  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
      this.uploader.queue.splice(0, this.uploader.queue.length - 1);
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);
      form.append('predictor_variable', this.pv);
      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      const responsePath = JSON.parse(response);
      this.feedbackpuploaderror = responsePath['Error'];

      this.feedbackpupload = responsePath['Upload Status'];
    };
  }


  check() {
    if (this.feedbackpupload === 'Uploaded Successfully') {
      this.run_Model();
    } else {
      this.uperror = 'upload file or check if there is an error in uploading process';
    }
}

run_Model() {
  this.file_upload = 'true';
  if (this.caution2 === false && this.caution === false) {
    const url = environment.API_URL + '/run_score_models';
    const classifier = [];
    AppConst.ClassifierList.forEach(x => {
      classifier.push(x.value);
    });
    // tslint:disable-next-line:max-line-length
    this.http.post(url, { vectors: this.vector, classifier: classifier, file_upload: this.file_upload, unseen_test_data: this.unseen_test_data, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(
      res => {
        this.errupmessage = JSON.parse(res['_body'])['Error'];

        this._uploadpredict = res.json()
        this.dataLength = this._uploadpredict.length;
        // console.log(this.dataLength)
        // console.log(this._uploadpredict[0])
        this.loadershow = false;
        this.getDetailedResult();
      },
      error => {
          console.log ("Error", error)
      });
  }
}

loadshow() {
  if (this.errupmessage === '' && this.dataLength === 0 && this.feedbackpupload === 'Uploaded Successfully') {
    this.loadershow = true;
  } else {
    this.loadershow = false;
  }

}

getDetailedResult() {
  const url = environment.API_URL + '/get_detailed_report';
  this.http.post(url, {outcome: this.outCome}).subscribe(
    res => {
      this.predictedScores = res.json();
      this.detailedResultView = true;
      this.createTableHeaders();
  });
}

hideDetailedResult() {
  this.detailedResultView = false;
  this.classifierHeaders = [];
}

public exportAsExcelFile(json: any[], excelFileName: string): void {
  const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
  const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
  const excelBuffer: any = XLSX.write(workbook, { bookType: 'xls', type: 'array' });
  this.saveAsExcelFile(excelBuffer, excelFileName);
}
private saveAsExcelFile(buffer: any, fileName: string): void {
  const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
  FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
}

createTableHeaders() {
  AppConst.ClassifierList.forEach(x => {
    this.classifierHeaders.push(x.name);
    this.classifierHeaders.push(x.name + ' Pobability');
  },
);
}


download(flag: boolean) {
  if(flag) {
    this.exportAsExcelFile(this._uploadpredict, 'PredictionOutput');
  } else {
    this.exportAsExcelFile(this.predictedScores, 'DetailedPredictionOutput');
  }
}

ngOnDestroy() {
  this.predictService.setPredictedDetailReport(this.predictedScores);
  this.predictService.setPredictedReport(this._uploadpredict);
}


}
