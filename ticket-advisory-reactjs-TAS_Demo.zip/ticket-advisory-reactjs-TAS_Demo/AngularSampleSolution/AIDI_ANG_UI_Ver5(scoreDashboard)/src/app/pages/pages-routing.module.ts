import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { PagesComponent } from './pages.component';
import { SimilarTicketsComponent } from './similar-tickets/similar-tickets.component';
import { PredictComponent} from './predict/predict.component';
import { TrainComponent } from './train/train.component';
import { ScoreDashboardComponent } from './score-dashboard/score-dashboard.component';

const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
  {
    path: 'Predict',
    component: PredictComponent,
  },
  {
    path: 'Train',
    component: TrainComponent,
  },
  {
    path: 'similarTickets',
    component: SimilarTicketsComponent,
  }, 
  {
    path: 'score-dashboard',
    component: ScoreDashboardComponent,
  },
  {
    path: '',
    redirectTo: 'Predict',
    pathMatch: 'full',
  }],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {
}
