export class AppConst{
    // tslint:disable-next-line:max-line-length
    // public static readonly ClassifierList = ['LinearSVC' , 'RandomForest', 'NaiveBayes','LogisticRegression', 'SGDClassifier'];
    public static readonly ClassifierList = [
        {name: 'Linear SVC', value: 'LinearSVC'},
        {name: 'Random Forest', value: 'RandomForest'},
        {name: 'Naive Bayes', value: 'NaiveBayes'},
        {name: 'Logistic Regression', value: 'LogisticRegression'},
        {name: 'SGD Classifier', value: 'SGDClassifier'},
    ];
}
