import { Injectable } from '@angular/core';

@Injectable()
export class PredictedDataService {

  predictedDetailReport = null;
  predictedReport = null;

  constructor() { }

  setPredictedDetailReport(data: any) {
    this.predictedDetailReport = data;
  }

  setPredictedReport(data: any) {
    this.predictedReport = data;
  }

  getPredictedDetailReport() {
    return this.predictedDetailReport;
  }

  getPredictedReport() {
    return this.predictedReport;
  }

}
