export interface ManualUpload {
    Notes: any;
    IncidentID: any;
    Prediction_Outcome: any;
    isSatisfied: boolean;
    isNotSatisfied: boolean;
    predicted_class_prob: number;
}
