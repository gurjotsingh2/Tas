export interface ManualUpload {
    Notes:any;
    IncidentID:any;
    outcome:any;
    isSatisfied: boolean;
    isNotSatisfied: boolean;
}
