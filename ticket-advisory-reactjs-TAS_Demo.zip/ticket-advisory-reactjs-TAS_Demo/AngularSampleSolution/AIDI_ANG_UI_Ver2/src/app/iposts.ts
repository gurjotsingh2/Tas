export interface Iposts {
    class: any,
    f1_score: any,
    false_negative: any,
    false_positive: any,
    precision: any,
    recall: any
}
