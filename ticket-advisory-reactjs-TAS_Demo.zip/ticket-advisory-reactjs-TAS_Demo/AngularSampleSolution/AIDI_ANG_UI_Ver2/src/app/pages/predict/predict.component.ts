import { Component, OnInit } from '@angular/core';
import { FileSelectDirective, FileUploader } from 'ng2-file-upload';
import { Http, Response } from '@angular/http';
import { Iposts } from '../../iposts';
import { ManualUpload } from '../../manual-upload';
// import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { AppComponent } from '../../app.component';
import { environment } from './../../../environments/environment';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { feedbackUpload } from '../../feedback-upload';

const URL = environment.API_URL + '/predict_upload';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xls';

@Component({
  selector: 'predict',
  templateUrl: './predict.component.html',
  styleUrls: ['./predict.component.css'],
  providers: []
})
export class PredictComponent {
  _postsArray: Iposts[];
  _manualpredict: ManualUpload[];
  _uploadpredict: ManualUpload[];
  arr_of_manualprediction: any[] = [];
  // ab: string;
  pv: string;
  // ov: string;
  feedbackpupload: string = "";
  feedbackpuploaderror = "";
  myRadio: string = '';

  selectedEntry: feedbackUpload[] = [];

  public uploader: FileUploader = new FileUploader({ url: URL });

  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;


  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
      this.uploader.queue.splice(0, this.uploader.queue.length - 1);
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);
      form.append('predictor_variable', this.pv);
      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      var responsePath = JSON.parse(response);
      console.log(response, responsePath);// the url will be in the response
      this.feedbackpuploaderror = responsePath['Error'];

      this.feedbackpupload = responsePath['Upload Status'];
    };
  }
  show1: string = '';
  show2: string = '';
  show3: string = '';
  classifier_var: string = "LinearSVC";
  vector_var: string = "TF-IDF";
  outcome_var: string = "Resolution (Knowledge Base ID)";
  vector: string = 'tfidf';
  classifier: string = 'LinearSVC';
  outCome: string = 'BIT_Keywords_List';
  predictor: string = "Notes";
  file_upload: string = 'false';
  // classifier_array: any[] = [];
  // classifier_a1: any[] = [
  //   { name: "LinearSVC", value: "LinearSVC" },
  //   { name: "Random Forest", value: "RandomForest" },
  //   { name: "Naive Bayes", value: "NaiveBayes" }
  // ];
  // classifier_a2: any[] = [
  //   { name: "LinearSVC", value: "LinearSVC" },
  //   { name: "ExtraTree Classifier", value: "ExtraTreeClassifier" }
  // ];
  // classifier_a3: any[] = [
  //   { name: "LinearSVC", value: "LinearSVC" },
  //   { name: "Random Forest", value: "RandomForest" },
  //   { name: "Naive Bayes", value: "NaiveBayes" },
  //   { name: "ExtraTree Classifier", value: "ExtraTreeClassifier" }
  // ];
  // dropdown2() {
  //   if (this.vector == 'tfidf') {
  //     this.classifier_array = this.classifier_a1;
  //     console.log(this.classifier_a1);
  //   }
  //   if (this.vector == 'word2vec_tfidf') {
  //     this.classifier_array = this.classifier_a2;
  //   }
  //   if (this.vector == 'word2vec_avg') {
  //     this.classifier_array = this.classifier_a3;
  //   }
  // }
  caution: boolean = false;
  validresult: boolean = true;
  validresult2: boolean = true;
  validate() {
    if (this.vector == '' || this.classifier == '' || this.outCome == '') {
      this.validresult = false;
      this.caution = true;
    }
    else {
      this.validresult = true;
      this.caution = false;
    }
  }
  validate2() {
    if (this.caution == true) {
      this.caution2 = true;
    }
    else {
      this.caution2 = false;
    }
  }
  validatemanupload() {
    if (this.vector == '' || this.classifier == '' || this.outCome == '') {
      this.validresult2 = false;
    }
    else {
      this.validresult2 = true;
    }
    return this.validresult2;
  }
  settings = {
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      IncidentNumber: {
        title: 'Incident Number',
        type: 'string',

      },
      Notes: {
        title: 'Problem Description',
        type: 'string',
      },
    },
  };


  onCreateConfirm(event) {
    this.arr_of_manualprediction.push(event.newData);
    console.log(this.arr_of_manualprediction);
    event.confirm.resolve(event.newData);

  }
  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
      this.arr_of_manualprediction.pop();
      console.log(this.arr_of_manualprediction);
    } else {
      event.confirm.reject();
    }
  }

  constructor(private http: Http) { }
  unseen_test_data: any[] = [];
  abcd = 0;
  s = 0;
  errmessage: string = '';
  caution2: boolean = false;
  arr_length = 1
  lencheck() {
    if (this.arr_of_manualprediction.length == 0) {
      this.arr_length = 0;
    }
    else {
      this.arr_length = 1;
    }
  }

  run_Modelmanual() {
    this.file_upload = 'false';
    this.unseen_test_data = this.arr_of_manualprediction;
    if (this.validresult == true && this.arr_of_manualprediction.length != 0) {
      let url = environment.API_URL + '/run_model';

      console.log ("vectors:"+ this.vector +", classifier:"+ this.classifier+ ", file_upload:"+ this.file_upload + ", unseen_test_data:" + this.unseen_test_data + ", predictor_variable:"+ this.predictor +", output_variable:"+ this.outCome);
      this.http.post(url, { vectors: this.vector, classifier: this.classifier, file_upload: this.file_upload, unseen_test_data: this.unseen_test_data, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(
        res => {
          this.errmessage = JSON.parse(res['_body'])['Error'];
          // console.log(this.errmessage)
          this._manualpredict = res.json();
          this.s = this._manualpredict.length;
          this.unseen_test_data = [];
          // this.loadershow2 = false;
        });
    }
  }
  uperror: string = '';
  check() {
    if (this.feedbackpupload === 'Uploaded Successfully') {
      this.run_Model();
    }
    else {
      this.uperror = 'upload file or check if there is an error in uploading process';
    }

  }
  loadshow2() {
    if (this.errupmessage == '' && this.s == 0) {
      this.loadershow2 = true;
    }
    else {
      this.loadershow2 = false;
    }

  }
  loadshow() {
    if (this.errupmessage == '' && this.abcd == 0 && this.feedbackpupload === 'Uploaded Successfully') {
      this.loadershow = true;
    }
    else {
      this.loadershow = false;
    }

  }
  loadershow: boolean;
  loadershow2: boolean;
  errupmessage: string = '';
  run_Model() {
    this.file_upload = 'true';
    if (this.caution2 == false && this.caution == false) {
      let url = environment.API_URL + '/run_model';
      console.log ("vectors:"+ this.vector +", classifier:"+ this.classifier+ ", file_upload:"+ this.file_upload + ", unseen_test_data:" + this.unseen_test_data + ", predictor_variable:"+ this.predictor +", output_variable:"+ this.outCome);
      this.http.post(url, { vectors: this.vector, classifier: this.classifier, file_upload: this.file_upload, unseen_test_data: this.unseen_test_data, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(
        res => {
          this.errupmessage = JSON.parse(res['_body'])['Error'];

          this._uploadpredict = res.json()
          //this._uploadpredict = JSON.parse(res.json())
          console.log(JSON.stringify(this._uploadpredict))

          this.abcd = this._uploadpredict.length;
          console.log(this.abcd)
          console.log(this._uploadpredict[0])
          this.loadershow = false;
        },
        error =>{
            console.log ("Error", error)
        });
    }
  }
  public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xls', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }
  download() {
    this.exportAsExcelFile(this._uploadpredict, 'PredictionOutput');
  }
  download1() {
    this.exportAsExcelFile(this._manualpredict, 'PredictionOutput');

  }

  display(data) {
    console.log(data);
  }

  sendFeedback() {
    // this.http.post('web api path',this.selectedEntry)
    // .subscribe(Response => data = Response)
    // ;
  }


  onSelectionChange(entry) {
    let flag = -1;
    for (var i of this.selectedEntry) {
      if (i.feedbackId == entry.target.name) {
        flag = this.selectedEntry.indexOf(i);
        break;
      }
    }
    if (flag != -1) {
      this.selectedEntry.splice(flag, 1);
      this.selectedEntry.push({ 'feedbackId': entry.target.name, 'feedbackDesc': entry.target.id });
      console.log(this.selectedEntry);
    }
    else {
      this.selectedEntry.push({ 'feedbackId': entry.target.name, 'feedbackDesc': entry.target.id });
      console.log(this.selectedEntry);
    }
  }
 
}
