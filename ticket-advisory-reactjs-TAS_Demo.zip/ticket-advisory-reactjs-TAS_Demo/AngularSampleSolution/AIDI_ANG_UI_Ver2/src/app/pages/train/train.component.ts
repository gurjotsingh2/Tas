import { Component, OnInit } from '@angular/core';
import { FileSelectDirective, FileUploader } from 'ng2-file-upload';
import { Http, Response } from '@angular/http';
import { Iposts } from '../../iposts';
import { Train } from '../../train';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import {environment} from './../../../environments/environment'
const URL = environment.API_URL+'/train_upload';


@Component({
  selector: 'train',
  templateUrl: './train.component.html',
  styleUrls: ['./train.component.scss']
})
export class TrainComponent {
  _postsArray: Iposts[];//Array for measure report
  _traindata: Train[];//for train  result

  show1: string = '';//for label toggle
  show2: string = '';//for label toggle
  show3: string = '';//for label toggle


  //for drop down toggle
  classifier_var: string = "Select Classifier";
  vector_var: string = "Select Approach";
  outcome_var: string = "What you want to train?";
  vector: string = '';
  classifier: string = '';
  outCome: string = '';
  predictor: string = "Notes";
  file_upload: string = 'false';
  classifier_array: any[] = [];
  classifier_a1: any[] = [
    { name: "LinearSVC", value: "LinearSVC" },
    { name: "Random Forest", value: "RandomForest" },
    { name: "Naive Bayes", value: "NaiveBayes" }
  ];
  classifier_a2: any[] = [
    { name: "LinearSVC", value: "LinearSVC" },
    { name: "ExtraTree Classifier", value: "ExtraTreeClassifier" }
  ];
  classifier_a3: any[] = [
    { name: "LinearSVC", value: "LinearSVC" },
    { name: "Random Forest", value: "RandomForest" },
    { name: "Naive Bayes", value: "NaiveBayes" },
    { name: "ExtraTree Classifier", value: "ExtraTreeClassifier" }
  ];
  dropdown2() {

    if (this.vector == 'tfidf') {

      this.classifier_array = this.classifier_a1;
      console.log(this.classifier_a1);

    }
    if (this.vector == 'word2vec_tfidf') {
      this.classifier_array = this.classifier_a2;

    }
    if (this.vector == 'word2vec_avg') {
      this.classifier_array = this.classifier_a3;

    }
  }



  //File UPload

  feedbacktupload: string = "";//upload feedback
  feedbacktuploaderror = "";//upload feedback
  public uploader: FileUploader = new FileUploader({ url: URL });
  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);

      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      var responsePath = JSON.parse(response);
      this.feedbacktuploaderror = responsePath['Error'];
      this.feedbacktupload = responsePath['Upload Status'];

      console.log(response, responsePath);
      console.log(typeof responsePath);
      console.log(this.feedbacktupload)
      //this.err = JSON.parse(response['_body'])["Error"];
      // console.log(this.err);
      // the url will be in the response
    };

  }


  //error handling and validation
  cautionbutton: boolean;
  cautiontrain: boolean;
  validresult: boolean = true;
  message: string='OK';
  validatetrain() {
    if (this.vector == '' || this.classifier == '' || this.outCome == '') {
      this.message = '';
      this.cautiontrain = true;
    }
    else {
      this.cautiontrain = false;
    
    }

  }
  constructor(private http: Http) { }

filecaution:boolean;
  exmessage: string = 'Model is already trained';
  d: string = "";
  a() {
    if (this.cautiontrain == false && this.file_upload == 'true') {
      this.message = 'hi';
      this.cautionbutton = false;
      this.filecaution=false;
    }
    else {
      this.cautionbutton = true;
      this.filecaution=true;
    }
  }
 
  trainerror: string = '';



  train_model(): any {
    if (this.cautionbutton == false) {
      let url = environment.API_URL + '/train_model';

      this.http.post(url, { vectors: this.vector, classifier: this.classifier, predictor_variable: this.predictor, output_variable: this.outCome, file_upload: this.file_upload }).subscribe(
        res => {
          res.json();
          this._traindata = JSON.parse(res['_body'])["Performance_Measure"];
          console.log(this._traindata);
          this.message = JSON.parse(res['_body'])["Model_status"];
          if (this.message === this.exmessage || this.message === 'Model is trained') {
            this.report();
          }
          console.log(this.message);
          this.trainerror = JSON.parse(res['_body'])['Error'];
          this.cautionbutton=true;
        });
    }

  }
  report() {
    // if(this.cautiontrain==false && this.message===this.exmessage||this.message==='Model is trained'){
    let url = environment.API_URL+ '/measure_report';
    this.http.post(url, { vectors: this.vector, classifier: this.classifier, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(res => this._postsArray = res.json());
    // }

  }

 

  download() {
    var options = {
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true,
      showTitle: false,
      headers: ['Class', 'F1_Score', 'False_Negative', 'False_positive', 'Precision', 'Recall']
    };
    console.log(this._postsArray);
    new Angular5Csv(this._postsArray, 'Report ' + this.vector + ' ' + this.classifier, options);
  }

}