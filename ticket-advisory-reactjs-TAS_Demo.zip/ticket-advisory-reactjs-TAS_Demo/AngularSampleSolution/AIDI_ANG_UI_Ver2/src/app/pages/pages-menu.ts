import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
 
  {
    title: 'Predict Category',
    icon: 'nb-lightbulb',
    link: '/pages/Predict',
    home: true,
  },

  {
    title: 'Train Model',
    icon: 'nb-compose',
    link: '/pages/Train',
  }

];
