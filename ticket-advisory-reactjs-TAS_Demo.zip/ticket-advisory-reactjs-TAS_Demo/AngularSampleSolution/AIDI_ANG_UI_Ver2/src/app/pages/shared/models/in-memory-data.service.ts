import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const news = [
      { type: 11, text: 'Mr. Nice' },
    
    ];
    return {news};
  }
}