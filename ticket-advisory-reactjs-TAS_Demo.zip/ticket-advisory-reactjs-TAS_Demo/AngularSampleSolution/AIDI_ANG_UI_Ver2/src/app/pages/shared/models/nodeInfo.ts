export class Nodeinfo {
    id: string;
    url: string;
    name: string;
}

export const Ninfo = [
    {id: '001',
    url: 'URL',
    name: 'Demo'}
    ];