import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { environment } from '../../../environments/environment';
import { Http } from '@angular/http';
import { UserConfigModel } from './user-config.model';
const URL = environment.API_URL + '/train_upload';

@Component({
  selector: 'user-config',
  templateUrl: './user-config.component.html',
  styleUrls: ['./user-config.component.css'],
})
export class UserConfigComponent implements OnInit, AfterViewInit {

  constructor(private http: Http) { }

  ngOnInit() {
  }

  inputColumns: Array<any> = [
    {
      'name': '',
    },
  ];

  userConfigData = new UserConfigModel();
  dbName = '';
  outputColumn = '';
  outcome_var: string = 'What you want to train?';
  outCome = '';
  newAttribute: any = {};
  feedbacktupload: string = '';
  feedbacktuploaderror = '';
  // languages = ['English', 'French', 'German', 'Spanish'];
  // selectedLanguages = [];
  public uploader: FileUploader = new FileUploader({ url: URL });


  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);

      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      const responsePath = JSON.parse(response);
      this.feedbacktuploaderror = responsePath['Error'];
      this.feedbacktupload = responsePath['Upload Status'];
    };
  }




  addInputColumn() {
    this.inputColumns.push(this.newAttribute);
    this.newAttribute = {};
  }


  deleteInputColumn(index) {
    if (this.inputColumns.length > 1) {
      this.inputColumns.splice(index, 1);
    }
  }

  saveConfiguration() {
    const url = environment.API_URL + '/save_user_config';
    const inputColumnNames = this.inputColumns.map(x => {
      return x.name
    })

    this.userConfigData.dbName = this.dbName;
    this.userConfigData.inputColumns = inputColumnNames;
    // this.userConfigData.languages = this.selectedLanguages;
    this.userConfigData.outputColumn = this.outputColumn;
    this.userConfigData.userCase = this.outCome;
    this.removeEmptyFields();

    const body = JSON.stringify(this.userConfigData);
    console.log(body);

    this.http.post(url, this.userConfigData).subscribe( data => {
      console.log(data);
    },
    error => {

    });
  }

  removeEmptyFields() {
    this.userConfigData.inputColumns.forEach(element => {
      if (element === '') {
        const index = this.userConfigData.inputColumns.findIndex(x => x === element);
        this.userConfigData.inputColumns.splice(index, 1);
      }
    });

    if (this.userConfigData.outputColumn === '' || this.userConfigData.outputColumn == null) {
      this.userConfigData.outputColumn = null;
    }
    if (this.userConfigData.dbName === '' || this.userConfigData.dbName == null) {
      this.userConfigData.dbName = null;
    }
  }

  setUserConfig() {
    const url = environment.API_URL + '/retrieve_user_config';
    this.http.post(url, {outcome: this.outCome}).subscribe(data => {
      this.userConfigData = data.json()[0];
      this.dbName = this.userConfigData.dbName;
      this.outputColumn = this.userConfigData.outputColumn;
      const inputColumnNames = this.userConfigData.inputColumns;
      this.inputColumns = [];
      inputColumnNames.forEach(x => {
        this.inputColumns.push({'name': x});
      });
    });
  }

/*   checkboxClicked(e: any) {
    if (e.target.checked === true) {
      this.selectedLanguages.push(e.target.value)
    } else {
      const index = this.selectedLanguages.findIndex(x => x === e.target.value);
    this.selectedLanguages.splice(index, 1);
    }
  } */

}
