export class UserConfigModel {
  outputColumn: string;
  inputColumns: string[];
  dbName: string;
  userCase: string;
}
