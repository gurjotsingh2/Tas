import { Component, AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { environment } from '../../../environments/environment';
import { ManualUpload } from '../../manual-upload';
import { Http } from '@angular/http';
const URL = environment.API_URL + '/predict_upload';
import { AppConst } from '../constData';
import * as XLSX from 'xlsx';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xls';
import * as FileSaver from 'file-saver';
import { PredictedDataService } from '../../services/predicted-data.service';
@Component({
  selector: 'score-dashboard',
  templateUrl: './score-dashboard.component.html',
  styleUrls: ['./score-dashboard.component.css']
})

export class ScoreDashboardComponent implements OnInit,AfterViewInit,OnDestroy {
  public uploader: FileUploader = new FileUploader({ url: URL });
  feedbackpupload: string = '';
  feedbackpuploaderror = "";
  pv: string;
  outcome_var: string = "Resolution (Knowledge Base ID)";
  outCome: string = 'BIT_Keywords_List';
  outComes = ['BIT_Keywords_List', 'Assigned Group'];
  uperror: string = '';
  file_upload: string = 'true';
  caution2: boolean = false;
  caution: boolean = false;
  loadershow: boolean;
  errupmessage: string = '';
  errupmessageDetailed: string = '';
  dataLength = 0;
  _uploadpredict: ManualUpload[] = null;
  vector = 'tfidf';
  unseen_test_data = [];
  predictor: string = 'Notes';
  classifierHeaders = [];
  predictedScores: any = null;
  detailedResultView = false;
  dataLengthDetailed = 0;


  constructor( private http: Http, private predictService: PredictedDataService ) {}

  ngOnInit() {
    debugger;
    const predictedData = this.predictService.getPredictedReport();
    const predictedDetailReport = this.predictService.getPredictedDetailReport();
    if (predictedData != null) {
      this._uploadpredict = predictedData;
      this.dataLength = this._uploadpredict.length;
      this.errupmessage = undefined;
    }
    if (predictedDetailReport != null) {
      this.predictedScores = predictedDetailReport;
      this.detailedResultView = true;
      this.createTableHeaders();
    }
  }


  ngAfterViewInit() {
    debugger;
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
      this.uploader.queue.splice(0, this.uploader.queue.length - 1);
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);
      form.append('predictor_variable', this.pv);
      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      const responsePath = JSON.parse(response);
      this.feedbackpuploaderror = responsePath['Error'];

      this.feedbackpupload = responsePath['Upload Status'];
    };
  }


  check() {
    debugger;
    if (this.feedbackpupload === 'Uploaded Successfully') {
      this.run_Model();
    } else {
      this.uperror = 'upload file or check if there is an error in uploading process';
    }
}

run_Model() {
  debugger;
  this.file_upload = 'true';
  if (this.caution2 === false && this.caution === false) {
    const url = environment.API_URL + '/run_score_models';
    const classifier = [];
    AppConst.ClassifierList.forEach(x => {
      classifier.push(x.value);
    });
    // tslint:disable-next-line:max-line-length
    this.http.post(url, { vectors: this.vector, classifier: classifier, file_upload: this.file_upload, unseen_test_data: this.unseen_test_data, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(
      res => {
        this.errupmessage = JSON.parse(res['_body'])['Error'];

        this._uploadpredict = res.json()
        this.dataLength = this._uploadpredict.length;
        // console.log(this.dataLength)
        // console.log(this._uploadpredict[0])
        this.loadershow = false;
        this.getDetailedResult();
      },
      error => {
          console.log ("Error", error)
      });
  }
}

loadshow() {
  debugger;
  if (this.errupmessage === '' && this.dataLength === 0 && this.feedbackpupload === 'Uploaded Successfully') {
    this.loadershow = true;
  } else {
    this.loadershow = false;
  }

}

getDetailedResult() {
  debugger;
  const url = environment.API_URL + '/get_detailed_report';
  this.http.post(url, {outcome: this.outCome}).subscribe(
    res => {
      this.errupmessageDetailed = JSON.parse(res['_body'])['Error'];
      this.predictedScores = res.json();
      this.dataLengthDetailed = this.predictedScores.length;
      this.detailedResultView = true;
      this.createTableHeaders();
      this.loadershow = false;
  });
}

getBestProbResult() {
  debugger;
  this.dataLength = 0;
  this.detailedResultView = false;
  this.loadershow = true;
  const url = environment.API_URL + '/retreive_best_probability_record';
  this.http.post(url, { outcome: this.outCome }).subscribe(
    res => {
      this.errupmessage = JSON.parse(res['_body'])['Error'];

      this._uploadpredict = res.json()
      this.dataLength = this._uploadpredict.length;
      this.getDetailedResult();
    },
    error => {
        console.log ("Error", error)
    });
}

hideDetailedResult() {
  debugger;
  this.detailedResultView = false;
  this.classifierHeaders = [];
}

public exportAsExcelFile(json: any[], excelFileName: string): void {
  debugger;
  const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
  const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
  const excelBuffer: any = XLSX.write(workbook, { bookType: 'xls', type: 'array' });
  this.saveAsExcelFile(excelBuffer, excelFileName);
}
private saveAsExcelFile(buffer: any, fileName: string): void {
  debugger;
  const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
  FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
}

createTableHeaders() {
  debugger;
  this.classifierHeaders = [];
  AppConst.ClassifierList.forEach(x => {
    this.classifierHeaders.push(x.name);
    this.classifierHeaders.push(x.name + ' Pobability');
  },
);
}


download(flag: boolean) {
  debugger;
  if(flag) {
    this.exportAsExcelFile(this._uploadpredict, 'PredictionOutput');
  } else {
    this.exportAsExcelFile(this.predictedScores, 'DetailedPredictionOutput');
  }
}


ngOnDestroy() {
  debugger;
  this.predictService.setPredictedDetailReport(this.predictedScores);
  this.predictService.setPredictedReport(this._uploadpredict);
}


}
