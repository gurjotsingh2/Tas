import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { Http } from '@angular/http';
import { Iposts } from '../../iposts';
import { Train } from '../../train';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { environment } from './../../../environments/environment'
import { PatternModel } from './pattern.model';
const URL = environment.API_URL + '/train_upload';

@Component({
  selector: 'Pattern',
  templateUrl: './pattern.component.html',
  styleUrls: ['./pattern.component.css']
})
export class PatternComponent implements AfterViewInit {
  _postsArray: Iposts[]; //Array for measure report
  _traindata: Train[]; //for train  result

  show1: string = ''; //for label toggle
  show2: string = ''; //for label toggle
  show3: string = ''; //for label toggle

  checkboxChecked : boolean = true;
  userMessage = '';
  loader = false;
  //for drop down toggle
  classifier_var: string = 'Select Classifier';
  vector_var: string = 'Select Approach';
  outcome_var: string = 'What you want to train?';
  vector: string = '';
  classifier: string = '';
  outCome: string = '';
  predictor: string = 'Notes';
  file_upload: string = 'false';
  classifier_array: any[] = [];
  classifier_a1: any[] = [
    { name: 'LinearSVC', value: 'LinearSVC' },
    { name: 'Random Forest', value: 'RandomForest' },
    { name: 'Naive Bayes', value: 'NaiveBayes' },
  ];
  classifier_a2: any[] = [
    { name: 'LinearSVC', value: 'LinearSVC' },
    { name: 'ExtraTree Classifier', value: 'ExtraTreeClassifier' },
  ];
  classifier_a3: any[] = [
    { name: 'LinearSVC', value: 'LinearSVC' },
    { name: 'Random Forest', value: 'RandomForest' },
    { name: 'Naive Bayes', value: 'NaiveBayes' },
    { name: 'ExtraTree Classifier', value: 'ExtraTreeClassifier' },
  ];


  languages = ['English', 'French', 'German', 'Spanish'];
  selectedLanguageChecked = [false, false, false, false]
  selectedLanguages = [];
  uploadData = new PatternModel();

  dropdown2() {

    if (this.vector == 'tfidf') {

      this.classifier_array = this.classifier_a1;
      console.log(this.classifier_a1);

    }
    if (this.vector == 'word2vec_tfidf') {
      this.classifier_array = this.classifier_a2;

    }
    if (this.vector == 'word2vec_avg') {
      this.classifier_array = this.classifier_a3;

    }
  }



  //File UPload

  feedbacktupload = null; //upload feedback
  feedbacktuploaderror = null; //upload feedback
  public uploader: FileUploader = new FileUploader({ url: URL });
  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('output_variable', this.outCome);

      return { item, form };
    }
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      const responsePath = JSON.parse(response);
      this.feedbacktuploaderror = responsePath['Error'];
      this.feedbacktupload = responsePath['Upload Status'];

      console.log(response, responsePath);
      console.log(typeof responsePath);
      console.log(this.feedbacktupload)
      //this.err = JSON.parse(response['_body'])["Error"];
      // console.log(this.err);
      // the url will be in the response
    };

  }


  //error handling and validation
  cautionbutton: boolean;
  cautiontrain: boolean;
  validresult: boolean = true;
  message: string = 'OK';
  validatetrain() {
    if (this.vector == '' || this.classifier == '' || this.outCome == '') {
      this.message = '';
      this.cautiontrain = true;
    }
    else {
      this.cautiontrain = false;

    }

  }
  constructor(private http: Http) { }

  filecaution: boolean;
  exmessage: string = 'Model is already trained';
  d: string = '';
  a() {
    if (this.cautiontrain == false && this.file_upload == 'true') {
      this.message = 'hi';
      this.cautionbutton = false;
      this.filecaution = false;
    }
    else {
      this.cautionbutton = true;
      this.filecaution = true;
    }
  }

  trainerror: string = '';



  train_model(): any {
    if (this.cautionbutton == false) {
      const url = environment.API_URL + '/train_model';

      this.http.post(url, { vectors: this.vector, classifier: this.classifier, predictor_variable: this.predictor, output_variable: this.outCome, file_upload: this.file_upload }).subscribe(
        res => {
          res.json();
          this._traindata = JSON.parse(res['_body'])['Performance_Measure'];
          console.log(this._traindata);
          this.message = JSON.parse(res['_body'])['Model_status'];
          if (this.message === this.exmessage || this.message === 'Model is trained') {
            this.report();
          }
          console.log(this.message);
          this.trainerror = JSON.parse(res['_body'])['Error'];
          this.cautionbutton = true;
        });
    }

  }
  report() {
    // if(this.cautiontrain==false && this.message===this.exmessage||this.message==='Model is trained'){
    const url = environment.API_URL + '/measure_report';
    this.http.post(url, { vectors: this.vector, classifier: this.classifier, predictor_variable: this.predictor, output_variable: this.outCome }).subscribe(res => this._postsArray = res.json());
    // }

  }



  download() {
    const options = {
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true,
      showTitle: false,
      headers: ['Class', 'F1_Score', 'False_Negative', 'False_positive', 'Precision', 'Recall'],
    };
    console.log(this._postsArray);
    new Angular5Csv(this._postsArray, 'Report ' + this.vector + ' ' + this.classifier, options);
  }

  fieldArray: Array<any> = [
    {
      'name': '',
      'endName': '',
    },
  ];


  newAttribute: any = {};



  addFieldValue(index) {
    this.fieldArray.push(this.newAttribute);
    this.newAttribute = {};
  }


  deleteFieldValue(index) {
    if (this.fieldArray.length > 1) {
      this.fieldArray.splice(index, 1);
    }
  }

  checkboxClicked(e: any) {
    if (e.target.checked === true) {
      this.selectedLanguages.push(e.target.value)
    } else {
      const index = this.selectedLanguages.findIndex(x => x === e.target.value);
      this.selectedLanguages.splice(index, 1);
    }
  }

  clean_user_pattern() {
    this.userMessage = '';
    const url = environment.API_URL + '/clean_user_pattern';
    if (this.feedbacktupload != null) {
      this.uploadData.classifier = this.classifier;
      this.uploadData.outcome = this.outCome;
      this.uploadData.vector = this.vector;
      this.uploadData.regex = this.fieldArray;
      this.uploadData.language = this.selectedLanguages;
      this.loader = true;
      // const body = JSON.stringify(this.uploadData);
      this.http.post(url, this.uploadData).subscribe(data => {
        console.log('Data cleaned successfully');
        this.loader = false;
        this.userMessage = data.json().Message;
      },
      error => {
        console.log('Error in cleaning data');
        this.loader = false;
      });
    } else {
      console.log('Please upload file first');
      this.userMessage = 'Please upload file first';
    }
  }

  fetchUserConfig() {
    const url = environment.API_URL + '/retrieve_user_patterns'
    this.http.post(url, {outcome: this.outCome}).subscribe(data => {
      console.log(data);
      if (JSON.parse(data['_body'])['Error'] === undefined) {
        this.uploadData = data.json()[0];
        this.fieldArray = this.uploadData.regex;
        this.selectedLanguages = this.uploadData.language;
        this.langaugeExists();
      }else {
        console.log(JSON.parse(data['_body'])['Error']);
      }
    });
  }

  langaugeExists() {
    for (let i = 0; i < this.selectedLanguageChecked.length; i++) {
      this.selectedLanguages.forEach(language => {
        const index = this.selectedLanguages.findIndex(x => x === language);
        if (index !== -1) {
          this.selectedLanguageChecked[index] = true;
        }
      });
    }
  }

}
