export class PatternModel {
    vector: string;
    classifier: string;
    outcome: string;
    language: string[];
    regex: Regex[];
}

export class Regex {
    name: string;
    endName: string;
}
