export interface feedbackUpload {
    feedbackId: string;
    feedbackDesc: string
    }
