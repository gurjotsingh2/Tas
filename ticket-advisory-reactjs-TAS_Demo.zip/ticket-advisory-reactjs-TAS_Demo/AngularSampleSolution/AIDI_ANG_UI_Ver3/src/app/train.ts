export interface Train {

    False_Negative: any;
    False_Positive: any;
    Test_Accuracy: any;
}
