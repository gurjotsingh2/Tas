import { NgModule } from '@angular/core';

import { PagesComponent } from './pages.component';

import { PagesRoutingModule } from './pages-routing.module';
import { ThemeModule } from '../@theme/theme.module';

import { Ng2SmartTableModule } from 'ng2-smart-table';
import { PredictComponent } from './predict/predict.component';
import { TrainComponent } from './train/train.component';
import { FileUploadModule } from 'ng2-file-upload';
import { SimilarTicketsComponent } from './similar-tickets/similar-tickets.component';


const PAGES_COMPONENTS = [
  PagesComponent,
];

@NgModule({
  imports: [
    PagesRoutingModule,
    ThemeModule,

    Ng2SmartTableModule,
    FileUploadModule,
  ],
  declarations: [
    ...PAGES_COMPONENTS,
    PredictComponent,
    TrainComponent,
    SimilarTicketsComponent,
  ],
})
export class PagesModule {
}
