import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'similar-tickets',
  templateUrl: './similar-tickets.component.html',
  styleUrls: ['./similar-tickets.component.scss'],
})
export class SimilarTicketsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
