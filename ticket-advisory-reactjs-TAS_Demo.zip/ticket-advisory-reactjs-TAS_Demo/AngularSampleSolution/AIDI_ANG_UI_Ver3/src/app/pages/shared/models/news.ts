export class news {
    type: string;
    text: string;
}

export const Models1 = [
    {type: 'Name',
    text: 'Demo_new'},
    {type: 'PAN',
    text: '5678'},
    {type: 'Passport',
    text: '9012'},
]

export const Models = [
    {type: 'Name',
    text: 'Demo'},
    {type: 'PAN',
    text: '1234'},
    {type: 'Passport',
    text: '5678'},
  ];

